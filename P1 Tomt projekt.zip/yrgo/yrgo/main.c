#include <avr/io.h>


/*Include the correct header file */
#include "p0/P0.h"
#include "p1/P1.h"
#include <time.h>
#include <util/delay.h>
#include <stdbool.h>
#include <stdio.h>

int main(void)
{
    /*Use either setup_p0 OR setup_p1*/
    //setup_p0();
    setup_p1();
    while(1) {

    }
}